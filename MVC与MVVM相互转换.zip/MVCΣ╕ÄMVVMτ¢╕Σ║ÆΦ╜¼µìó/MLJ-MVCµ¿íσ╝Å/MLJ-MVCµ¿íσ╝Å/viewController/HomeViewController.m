//
//  HomeViewController.m
//  MLJ-MVC模式
//
//  Created by 茅露军 on 2017/9/26.
//  Copyright © 2017年 茅露军. All rights reserved.
//

#import "HomeViewController.h"
#import "MovieCell.h"
#import "MovieModel.h"
#import "NetworkService.h"
#import "MovieViewController.h"
@interface HomeViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic,strong) NSArray *modelArray;

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"电影首页";
    self.view.backgroundColor = [UIColor redColor];
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.rowHeight = 80;
    [self.view addSubview:tableView];
    [tableView registerClass:[MovieCell class] forCellReuseIdentifier:@"MovieCell"];
    
    _modelArray = [NSArray array];
    
    [NetworkService requestWithURL:@"/v2/movie/coming_soon" params:nil success:^(id result) {
        _modelArray = result[@"subjects"];
        [tableView reloadData];
    } failure:^(NSError *error) {
        NSLog(@"%@",error);
    }];
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
//    NSLog(@"%lu",(unsigned long)_modelArray.count);
    return _modelArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    MovieCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MovieCell"];
    cell.model = [MovieModel movieWithDic:_modelArray[indexPath.row]];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    MovieViewController *movieVC = [[MovieViewController alloc] init];
    movieVC.dic = _modelArray[indexPath.row];
    [self.navigationController pushViewController:movieVC animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
