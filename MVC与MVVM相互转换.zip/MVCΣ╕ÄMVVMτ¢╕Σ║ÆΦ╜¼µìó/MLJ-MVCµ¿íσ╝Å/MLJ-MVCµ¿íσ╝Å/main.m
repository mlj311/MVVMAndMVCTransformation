//
//  main.m
//  MLJ-MVC模式
//
//  Created by 茅露军 on 2017/9/26.
//  Copyright © 2017年 茅露军. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
