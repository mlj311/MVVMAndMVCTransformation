//
//  MovieModel.h
//  MLJ-MMVC模式
//
//  Created by 茅露军 on 2017/9/26.
//  Copyright © 2017年 茅露军. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MovieModel : NSObject
@property(copy,nonatomic) NSString *movieName;
@property(copy,nonatomic) NSString *year;
@property(copy,nonatomic) NSURL *imageUrl;
@property(copy,nonatomic) NSString *detailUrl;

+(instancetype)movieWithDic:(NSDictionary *)dic;
-(instancetype)initWithDic:(NSDictionary *)dic;

+(NSString *)getUrlWithDic:(NSDictionary *)dic;
@end
