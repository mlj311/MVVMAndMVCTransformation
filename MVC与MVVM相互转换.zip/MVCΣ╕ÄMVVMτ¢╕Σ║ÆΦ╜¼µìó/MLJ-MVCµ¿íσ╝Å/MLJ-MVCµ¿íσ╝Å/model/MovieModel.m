//
//  MovieModel.m
//  MLJ-MMVC模式
//
//  Created by 茅露军 on 2017/9/26.
//  Copyright © 2017年 茅露军. All rights reserved.
//

#import "MovieModel.h"
#import "MovieViewController.h"
@implementation MovieModel
+(instancetype)movieWithDic:(NSDictionary *)dic{
    return [[MovieModel alloc]initWithDic:dic];
}
-(instancetype)initWithDic:(NSDictionary *)dic{
    if (self = [super init]) {
        self.movieName = dic[@"title"];
        self.year = dic[@"year"];
        NSString *urlStr = dic[@"images"][@"medium"];
        self.imageUrl = [NSURL URLWithString:urlStr];
        self.detailUrl = dic[@"alt"];
    }
    return self;
}
+(NSString *)getUrlWithDic:(NSDictionary *)dic{
    NSString *url = dic[@"alt"];
    return url;
}
@end
