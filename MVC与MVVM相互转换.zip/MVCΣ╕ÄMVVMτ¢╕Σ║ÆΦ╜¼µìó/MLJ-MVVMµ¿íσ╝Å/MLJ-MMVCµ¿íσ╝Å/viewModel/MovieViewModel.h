//
//  MovieViewModel.h
//  MLJ-MMVC模式
//
//  Created by 茅露军 on 2017/9/26.
//  Copyright © 2017年 茅露军. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "MovieModel.h"

typedef void(^ReturnValueBlock)(id returnValue);
typedef void(^ErrorCodeBlock)(id errorCode);

@interface MovieViewModel : NSObject
@property (nonatomic,strong) ReturnValueBlock returnBlock;
@property (nonatomic,strong) ErrorCodeBlock errorBlock;

-(void)getMovieData;

-(void)movieDetailWithPublicModel:(MovieModel *)movieModel withViewController:(UIViewController *)superController;
@end
