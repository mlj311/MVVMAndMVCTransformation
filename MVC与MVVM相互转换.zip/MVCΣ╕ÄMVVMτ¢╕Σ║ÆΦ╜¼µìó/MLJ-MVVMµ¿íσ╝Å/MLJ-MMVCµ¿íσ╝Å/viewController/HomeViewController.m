//
//  HomeViewController.m
//  MLJ-MMVC模式
//
//  Created by 茅露军 on 2017/9/26.
//  Copyright © 2017年 茅露军. All rights reserved.
//

#import "HomeViewController.h"
#import "MovieViewModel.h"
#import "MovieCell.h"
@interface HomeViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic,strong) NSArray *modelArray;
@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"电影首页";
    self.view.backgroundColor = [UIColor redColor];
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.rowHeight = 80;
    [self.view addSubview:tableView];
    [tableView registerClass:[MovieCell class] forCellReuseIdentifier:@"MovieCell"];
    
    MovieViewModel *viewModel = [[MovieViewModel alloc]init];
    viewModel.returnBlock = ^(id returnValue){
        _modelArray = returnValue;
        [tableView reloadData];
    };
    viewModel.errorBlock = ^(id errorCode) {
        NSLog(@"%@",errorCode);
    };
    [viewModel getMovieData];
}
#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _modelArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    MovieCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MovieCell"];
    cell.model = _modelArray[indexPath.row];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    MovieViewModel *movieModel = [[MovieViewModel alloc]init];
    [movieModel movieDetailWithPublicModel:_modelArray[indexPath.row] withViewController:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
