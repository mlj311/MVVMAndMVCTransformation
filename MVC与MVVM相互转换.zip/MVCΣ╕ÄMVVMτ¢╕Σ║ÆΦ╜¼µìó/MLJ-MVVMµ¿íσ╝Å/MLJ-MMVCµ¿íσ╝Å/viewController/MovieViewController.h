//
//  MovieViewController.h
//  MLJ-MMVC模式
//
//  Created by 茅露军 on 2017/9/26.
//  Copyright © 2017年 茅露军. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MovieViewController : UIViewController
@property (nonatomic,copy) NSString *url;
@end
